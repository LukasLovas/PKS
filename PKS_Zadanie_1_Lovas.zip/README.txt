Lukáš Lovás PKS Zadanie 1:

-validator mi ukazuje successful az na jeden specificky typ frame-u, jeden protokol ktory sme este neboli povinny spracovat a mohli sme ho podla pokynov cviciaceho ignorovat.

-v pripade akychkolvek problemov, preistotu prikladam aj pristup ku githubu. https://github.com/LukasLovas/PKS